This is a zip to install BG Info

Runs silently in the background (Though it closes in less than 1 sec)

Contents of this Zip:
 - BGinfo64.exe
 - Bginfo64ShortCut.exe
 - Default.bgi
 - network.vbs

To install
 - Create BGInfo Folder in "C:\Program Files"
 - Move BGinfo.exe & Default.bgi to "C:\Program Files\BGInfo"
 - Move Bginfo64ShortCut.exe to "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup"
 - restart computer, should run silently and exit silently

Using the VisualBasic Script (vbs)
 - Run BGInfo64.exe
 - Remove all entries except "Host Name"
 - In "Fields" choose the "Custom" button just below Fields box
 - Choose "New" -> "VB Script file"
 - Give this a unique name like "IP Address2"
 - Choose "IP Address2" from "Fields"
 - Save as "Default.bgi" or other template name

This script is linked to the N-Central Automation Manager
 - N-Central -> Actions -> Start Automation Manager
 - This script is called "BGinfo installer.amp"

Last Update
6/23

Updating
 - Check BGInfo v4.33 site for updates: https://learn.microsoft.com/en-us/sysinternals/downloads/bginfo
 - Create new Default.bgi (see using visualBasic Script above)
 - Move all files into a "BGInfoFBXTech" folder
 - Zip Folder
 - Upload to GitHub.com (support@fbxtech.com)

